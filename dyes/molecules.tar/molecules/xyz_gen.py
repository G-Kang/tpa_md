import os,sys


for i in xrange(1,16):
    os.system('sybylxyz D'+str(i))
